# Dallatur · Escala de Viagens

App PWA para consulta de escala de viagens da equipe Dallatur.

## Como publicar no Vercel (gratuito)

### Passo 1 — Criar conta
Acesse vercel.com e crie uma conta gratuita (pode usar Google ou GitHub).

### Passo 2 — Instalar Vercel CLI (opcional) ou usar o site
A forma mais fácil é pelo site:
1. Acesse vercel.com/new
2. Clique em "Browse" e suba a pasta deste projeto (zip)
3. Clique em Deploy

### Passo 3 — Instalar no celular
Depois de publicado, acesse o link no celular:
- **Android (Chrome):** Menu ⋮ → "Adicionar à tela inicial"
- **iPhone (Safari):** Botão compartilhar □↑ → "Adicionar à Tela de Início"

## Senha do admin
Senha padrão: **dallatur2024**
Para trocar, edite a linha `const ADMIN_PASS = "dallatur2024"` no arquivo `src/App.jsx`.

## Estrutura
- `src/App.jsx` — código principal do app
- `public/manifest.json` — configuração PWA
- `public/sw.js` — service worker (funciona offline)
- `public/icon-192.png` e `icon-512.png` — ícones do app
