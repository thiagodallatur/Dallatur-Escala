import { useState, useEffect } from "react";

// ─── Print block: funcionários não conseguem imprimir ────────────────────────
const NO_PRINT_STYLE = `
  @media print {
    body.no-print * { display: none !important; }
    body.no-print::after {
      display: block !important;
      content: "Impressão não permitida.";
      font-size: 24px;
      text-align: center;
      margin-top: 40px;
    }
  }
`;

// ─── Helpers ─────────────────────────────────────────────────────────────────
const ADMIN_PASS = "dallatur2024";
const STORE_KEY  = "dallatur_escala_v2";

function uid() { return Math.random().toString(36).slice(2, 9); }

function fmtDate(d) {
  if (!d) return "—";
  const [y, m, day] = d.split("-");
  return `${day}/${m}/${y}`;
}

function fmtTime(t) { return t || "—"; }

function load() {
  try { const r = localStorage.getItem(STORE_KEY); if (r) return JSON.parse(r); } catch {}
  return null;
}
function persist(data) {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(data)); } catch {}
}

// ─── Demo data ───────────────────────────────────────────────────────────────
const EMP = [
  { id: "e1", name: "Ana Lima" },
  { id: "e2", name: "Carlos Mendes" },
  { id: "e3", name: "Fernanda Rocha" },
];

const TRIPS = [
  { id: "t1", vehicle: "ABC-1234", destination: "Lisboa, Portugal", date: "2026-07-10", time: "08:00", employeeId: "e1" },
  { id: "t2", vehicle: "DEF-5678", destination: "Gramado, RS",      date: "2026-07-15", time: "06:30", employeeId: "e2" },
  { id: "t3", vehicle: "ABC-1234", destination: "Cancún, México",   date: "2026-08-02", time: "10:15", employeeId: "e3" },
  { id: "t4", vehicle: "GHI-9012", destination: "Buenos Aires, AR", date: "2026-08-20", time: "07:45", employeeId: "e1" },
];

function initState() {
  const s = load();
  return s || { employees: EMP, trips: TRIPS };
}

// ─── Shared tokens ────────────────────────────────────────────────────────────
const C = {
  blue:       "#1A4FA0",
  blueMid:    "#2563EB",
  blueLight:  "#EFF5FF",
  bluePale:   "#DBEAFE",
  dark:       "#0F172A",
  mid:        "#475569",
  muted:      "#94A3B8",
  border:     "#E2E8F0",
  surface:    "#F8FAFF",
  white:      "#FFFFFF",
  red:        "#EF4444",
  redLight:   "#FEF2F2",
};

const inp = {
  width: "100%", padding: "9px 12px", borderRadius: 8,
  border: `1px solid ${C.border}`, fontSize: 14,
  color: C.dark, background: C.white,
  boxSizing: "border-box", outline: "none",
  fontFamily: "inherit",
};

const lbl = {
  display: "block", fontSize: 11, fontWeight: 700,
  color: C.muted, marginBottom: 4, letterSpacing: "0.05em", textTransform: "uppercase",
};

const btnPrimary = {
  padding: "9px 18px", borderRadius: 8, border: "none",
  background: C.blue, color: C.white,
  fontWeight: 700, fontSize: 13, cursor: "pointer",
  fontFamily: "inherit",
};

const btnGhost = {
  padding: "9px 14px", borderRadius: 8,
  border: `1px solid ${C.border}`, background: C.white,
  color: C.mid, fontWeight: 600, fontSize: 13,
  cursor: "pointer", fontFamily: "inherit",
};

// ─── TripRow (card compacto) ──────────────────────────────────────────────────
function TripRow({ trip, empName, isOwn }) {
  const past = trip.date < new Date().toISOString().slice(0,10);
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "auto 1fr auto",
      gap: 0,
      borderRadius: 12,
      border: `1.5px solid ${isOwn ? C.blue : C.border}`,
      background: isOwn ? C.blueLight : C.white,
      overflow: "hidden",
      opacity: past ? 0.55 : 1,
      marginBottom: 10,
    }}>
      {/* Linha colorida lateral */}
      <div style={{ width: 4, background: isOwn ? C.blue : C.border }} />

      <div style={{ padding: "14px 16px" }}>
        {/* Destino */}
        <div style={{ fontWeight: 700, fontSize: 15, color: C.dark, marginBottom: 6 }}>
          ✈️ {trip.destination}
        </div>
        {/* Tags */}
        <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
          <Tag icon="🚌" label={trip.vehicle} />
          <Tag icon="📅" label={fmtDate(trip.date)} />
          <Tag icon="🕐" label={fmtTime(trip.time)} />
          {empName && <Tag icon="👤" label={empName} blue={isOwn} />}
        </div>
      </div>

      {past && (
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "center",
          padding: "0 14px", color: C.muted, fontSize: 11, fontWeight: 700,
          letterSpacing: "0.05em", textTransform: "uppercase",
        }}>Realizada</div>
      )}
    </div>
  );
}

function Tag({ icon, label, blue }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "3px 9px", borderRadius: 99,
      background: blue ? C.bluePale : "#F1F5F9",
      color: blue ? C.blue : C.mid,
      fontSize: 12, fontWeight: 600,
    }}>
      {icon} {label}
    </span>
  );
}

// ─── Admin Panel ──────────────────────────────────────────────────────────────
function AdminPanel({ state, setState }) {
  const [tab, setTab]         = useState("trips");
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId]   = useState(null);
  const [form, setForm]       = useState({});
  const [empInput, setEmpInput] = useState("");
  const [editEmpId, setEditEmpId] = useState(null);

  const sortedTrips = [...state.trips].sort((a,b) => (a.date+a.time) > (b.date+b.time) ? 1 : -1);

  function openNew() {
    setEditId(null);
    setForm({ vehicle: "", destination: "", date: "", time: "", employeeId: "" });
    setShowForm(true);
  }
  function openEdit(t) {
    setEditId(t.id);
    setForm({ ...t });
    setShowForm(true);
  }
  function saveTrip() {
    if (!form.vehicle || !form.destination || !form.date || !form.employeeId) return;
    setState(prev => {
      const trips = editId
        ? prev.trips.map(t => t.id === editId ? { ...form, id: editId } : t)
        : [...prev.trips, { ...form, id: uid() }];
      const next = { ...prev, trips };
      persist(next);
      return next;
    });
    setShowForm(false);
  }
  function deleteTrip(id) {
    if (!confirm("Excluir esta viagem?")) return;
    setState(prev => {
      const next = { ...prev, trips: prev.trips.filter(t => t.id !== id) };
      persist(next); return next;
    });
  }

  function addEmp() {
    const name = empInput.trim(); if (!name) return;
    setState(prev => {
      const next = { ...prev, employees: [...prev.employees, { id: uid(), name }] };
      persist(next); return next;
    });
    setEmpInput("");
  }
  function saveEmp() {
    const name = empInput.trim(); if (!name) return;
    setState(prev => {
      const employees = prev.employees.map(e => e.id === editEmpId ? { ...e, name } : e);
      const next = { ...prev, employees }; persist(next); return next;
    });
    setEditEmpId(null); setEmpInput("");
  }
  function deleteEmp(id) {
    if (!confirm("Remover funcionário?")) return;
    setState(prev => {
      const employees = prev.employees.filter(e => e.id !== id);
      const trips = prev.trips.map(t => t.employeeId === id ? { ...t, employeeId: "" } : t);
      const next = { ...prev, employees, trips }; persist(next); return next;
    });
  }

  return (
    <div>
      {/* Tabs */}
      <div style={{ display: "flex", gap: 6, marginBottom: 20 }}>
        {[["trips","✈️ Viagens"],["emps","👥 Funcionários"]].map(([v,l]) => (
          <button key={v} onClick={() => setTab(v)} style={{
            ...btnGhost,
            background: tab===v ? C.blue : C.white,
            color: tab===v ? C.white : C.blue,
            border: `1.5px solid ${tab===v ? C.blue : C.bluePale}`,
          }}>{l}</button>
        ))}
      </div>

      {/* ── VIAGENS ── */}
      {tab === "trips" && (
        <>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
            <span style={{ fontWeight:700, color:C.dark }}>{state.trips.length} viagen{state.trips.length!==1?"s":""}</span>
            <button onClick={openNew} style={btnPrimary}>+ Nova viagem</button>
          </div>

          {showForm && (
            <div style={{
              background: C.white, border: `1px solid ${C.bluePale}`,
              borderRadius: 12, padding: 20, marginBottom: 18,
              boxShadow: "0 4px 20px rgba(26,79,160,0.08)",
            }}>
              <div style={{ fontWeight:800, fontSize:15, color:C.blue, marginBottom:16 }}>
                {editId ? "Editar viagem" : "Nova viagem"}
              </div>

              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:14 }}>
                <div>
                  <label style={lbl}>Veículo (placa) *</label>
                  <input style={inp} value={form.vehicle||""} onChange={e=>setForm(f=>({...f,vehicle:e.target.value}))} placeholder="ABC-1234" />
                </div>
                <div>
                  <label style={lbl}>Funcionário *</label>
                  <select style={inp} value={form.employeeId||""} onChange={e=>setForm(f=>({...f,employeeId:e.target.value}))}>
                    <option value="">Selecione...</option>
                    {state.employees.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                  </select>
                </div>
                <div style={{ gridColumn:"1/-1" }}>
                  <label style={lbl}>Destino *</label>
                  <input style={inp} value={form.destination||""} onChange={e=>setForm(f=>({...f,destination:e.target.value}))} placeholder="Ex: Lisboa, Portugal" />
                </div>
                <div>
                  <label style={lbl}>Data *</label>
                  <input style={inp} type="date" value={form.date||""} onChange={e=>setForm(f=>({...f,date:e.target.value}))} />
                </div>
                <div>
                  <label style={lbl}>Horário</label>
                  <input style={inp} type="time" value={form.time||""} onChange={e=>setForm(f=>({...f,time:e.target.value}))} />
                </div>
              </div>

              <div style={{ display:"flex", gap:8 }}>
                <button onClick={saveTrip} style={btnPrimary}>Salvar</button>
                <button onClick={()=>setShowForm(false)} style={btnGhost}>Cancelar</button>
              </div>
            </div>
          )}

          {sortedTrips.length === 0 && (
            <div style={{ textAlign:"center", color:C.muted, padding:40 }}>Nenhuma viagem. Clique em "+ Nova viagem".</div>
          )}

          {sortedTrips.map(trip => {
            const emp = state.employees.find(e => e.id === trip.employeeId);
            return (
              <div key={trip.id} style={{ position:"relative" }}>
                <TripRow trip={trip} empName={emp?.name} isOwn={false} />
                <div style={{ position:"absolute", top:12, right:12, display:"flex", gap:6 }}>
                  <button onClick={()=>openEdit(trip)} style={{
                    ...btnGhost, padding:"4px 10px", fontSize:12,
                  }}>Editar</button>
                  <button onClick={()=>deleteTrip(trip.id)} style={{
                    padding:"4px 10px", borderRadius:6, border:`1px solid #FCA5A5`,
                    background:C.redLight, color:C.red, fontSize:12, cursor:"pointer", fontFamily:"inherit", fontWeight:600,
                  }}>Excluir</button>
                </div>
              </div>
            );
          })}
        </>
      )}

      {/* ── FUNCIONÁRIOS ── */}
      {tab === "emps" && (
        <>
          <div style={{ display:"flex", gap:8, marginBottom:16 }}>
            <input
              style={{ ...inp, flex:1 }}
              value={empInput}
              onChange={e=>setEmpInput(e.target.value)}
              onKeyDown={e=>e.key==="Enter"&&(editEmpId?saveEmp():addEmp())}
              placeholder="Nome do funcionário"
            />
            {editEmpId
              ? <><button onClick={saveEmp} style={btnPrimary}>Salvar</button>
                  <button onClick={()=>{setEditEmpId(null);setEmpInput("");}} style={btnGhost}>✕</button></>
              : <button onClick={addEmp} style={btnPrimary}>+ Adicionar</button>
            }
          </div>

          {state.employees.map(e => {
            const count = state.trips.filter(t=>t.employeeId===e.id).length;
            return (
              <div key={e.id} style={{
                display:"flex", alignItems:"center", gap:12,
                padding:"12px 16px", borderRadius:10,
                border:`1px solid ${C.border}`, background:C.white, marginBottom:8,
              }}>
                <Avatar name={e.name} size={38} />
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, color:C.dark }}>{e.name}</div>
                  <div style={{ fontSize:12, color:C.muted }}>{count} viagem{count!==1?"s":""}</div>
                </div>
                <button onClick={()=>{setEditEmpId(e.id);setEmpInput(e.name);}} style={{...btnGhost,padding:"4px 10px",fontSize:12}}>Editar</button>
                <button onClick={()=>deleteEmp(e.id)} style={{padding:"4px 10px",borderRadius:6,border:`1px solid #FCA5A5`,background:C.redLight,color:C.red,fontSize:12,cursor:"pointer",fontFamily:"inherit",fontWeight:600}}>Remover</button>
              </div>
            );
          })}
        </>
      )}
    </div>
  );
}

// ─── Avatar ───────────────────────────────────────────────────────────────────
function Avatar({ name, size=44 }) {
  return (
    <div style={{
      width:size, height:size, borderRadius:"50%", flexShrink:0,
      background:`linear-gradient(135deg,${C.blue},#60A5FA)`,
      display:"flex", alignItems:"center", justifyContent:"center",
      color:"#fff", fontWeight:800, fontSize:size*0.38,
    }}>{name?.[0]}</div>
  );
}

// ─── Employee View ─────────────────────────────────────────────────────────────
function EmployeeView({ state }) {
  const [selectedId, setSelectedId] = useState(null);

  // Bloqueia impressão enquanto na tela do funcionário
  useEffect(() => {
    document.body.classList.add("no-print");
    return () => document.body.classList.remove("no-print");
  }, []);

  // Bloqueia Ctrl+P / Cmd+P
  useEffect(() => {
    const block = e => {
      if ((e.ctrlKey || e.metaKey) && e.key === "p") { e.preventDefault(); e.stopPropagation(); }
    };
    window.addEventListener("keydown", block, true);
    return () => window.removeEventListener("keydown", block, true);
  }, []);

  const selected = state.employees.find(e => e.id === selectedId);
  const myTrips  = selected
    ? [...state.trips.filter(t => t.employeeId === selectedId)]
        .sort((a,b) => (a.date+a.time)>(b.date+b.time)?1:-1)
    : [];

  const upcoming = myTrips.filter(t => t.date >= new Date().toISOString().slice(0,10));
  const past     = myTrips.filter(t => t.date <  new Date().toISOString().slice(0,10));

  if (!selected) {
    return (
      <div>
        <div style={{ textAlign:"center", marginBottom:28, marginTop:4 }}>
          <div style={{ fontSize:44, marginBottom:10 }}>👋</div>
          <div style={{ fontSize:20, fontWeight:800, color:C.dark }}>Quem é você?</div>
          <div style={{ color:C.muted, fontSize:14, marginTop:4 }}>Selecione seu nome para ver sua escala</div>
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          {state.employees.map(e => {
            const próxima = [...state.trips.filter(t=>t.employeeId===e.id)]
              .filter(t=>t.date>=new Date().toISOString().slice(0,10))
              .sort((a,b)=>a.date>b.date?1:-1)[0];
            return (
              <button key={e.id} onClick={()=>setSelectedId(e.id)} style={{
                display:"flex", alignItems:"center", gap:14,
                padding:"16px 18px", borderRadius:14,
                border:`1.5px solid ${C.bluePale}`, background:C.white,
                cursor:"pointer", textAlign:"left", width:"100%",
                fontFamily:"inherit",
              }}>
                <Avatar name={e.name} size={46} />
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, fontSize:16, color:C.dark }}>{e.name}</div>
                  <div style={{ fontSize:12, color:C.muted, marginTop:2 }}>
                    {próxima ? `Próxima: ${fmtDate(próxima.date)} · ${próxima.destination}` : "Sem viagens agendadas"}
                  </div>
                </div>
                <span style={{ color:C.bluePale, fontSize:22 }}>›</span>
              </button>
            );
          })}
          {state.employees.length===0 && (
            <div style={{ textAlign:"center", color:C.muted, padding:40 }}>
              Aguardando o administrador configurar o sistema.
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div>
      {/* Back + header */}
      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:22 }}>
        <button onClick={()=>setSelectedId(null)} style={btnGhost}>← Voltar</button>
        <Avatar name={selected.name} size={36} />
        <div style={{ fontWeight:800, fontSize:17, color:C.dark }}>{selected.name}</div>
      </div>

      {/* Aviso anti-print visível */}
      <div style={{
        background:"#FFF7ED", border:"1px solid #FED7AA",
        borderRadius:10, padding:"10px 14px",
        fontSize:12, color:"#92400E", marginBottom:20,
        display:"flex", alignItems:"center", gap:8,
      }}>
        🔒 Esta escala é de uso interno. Impressão e capturas de tela não são permitidas.
      </div>

      {upcoming.length === 0 && past.length === 0 && (
        <div style={{ textAlign:"center", color:C.muted, padding:48 }}>
          <div style={{ fontSize:36, marginBottom:8 }}>🗓️</div>
          Você não tem viagens na escala.
        </div>
      )}

      {upcoming.length > 0 && (
        <>
          <SectionLabel>Próximas viagens</SectionLabel>
          {upcoming.map(t => <TripRow key={t.id} trip={t} isOwn={true} />)}
        </>
      )}

      {past.length > 0 && (
        <>
          <SectionLabel style={{ marginTop:20 }}>Viagens realizadas</SectionLabel>
          {past.map(t => <TripRow key={t.id} trip={t} isOwn={true} />)}
        </>
      )}
    </div>
  );
}

function SectionLabel({ children, style }) {
  return (
    <div style={{
      fontSize:11, fontWeight:700, color:C.muted,
      letterSpacing:"0.07em", textTransform:"uppercase",
      marginBottom:10, ...style,
    }}>{children}</div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [state, setState]   = useState(initState);
  const [screen, setScreen] = useState("home");
  const [pass, setPass]     = useState("");
  const [passErr, setPassErr] = useState(false);

  function tryAdmin() {
    if (pass === ADMIN_PASS) { setScreen("admin"); setPass(""); setPassErr(false); }
    else setPassErr(true);
  }

  return (
    <div style={{ minHeight:"100vh", background:C.surface, fontFamily:"'Inter','Segoe UI',sans-serif" }}>
      <style>{NO_PRINT_STYLE}</style>

      {/* Header */}
      <div style={{
        background:`linear-gradient(135deg,${C.blue} 0%,${C.blueMid} 100%)`,
        padding:"0 24px", boxShadow:"0 2px 12px rgba(26,79,160,0.25)",
      }}>
        <div style={{ maxWidth:680, margin:"0 auto", display:"flex", alignItems:"center", justifyContent:"space-between", height:58 }}>
          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:20 }}>✈️</span>
            <span style={{ color:"#fff", fontWeight:800, fontSize:17, letterSpacing:"-0.3px" }}>Dallatur</span>
            <span style={{ color:"#93C5FD", fontSize:13, marginLeft:2 }}>Escala de Viagens</span>
          </div>
          {screen !== "home" && (
            <button onClick={()=>setScreen("home")} style={{
              padding:"5px 14px", borderRadius:8,
              border:"1px solid rgba(255,255,255,0.3)",
              background:"rgba(255,255,255,0.1)",
              color:"#fff", fontSize:13, cursor:"pointer", fontWeight:600, fontFamily:"inherit",
            }}>Início</button>
          )}
        </div>
      </div>

      {/* Body */}
      <div style={{ maxWidth:680, margin:"0 auto", padding:"28px 20px 60px" }}>

        {screen === "home" && (
          <div>
            <div style={{ textAlign:"center", marginBottom:36, marginTop:4 }}>
              <div style={{ fontSize:46, marginBottom:10 }}>🌍</div>
              <div style={{ fontSize:22, fontWeight:800, color:C.dark, letterSpacing:"-0.4px" }}>Escala de Viagens</div>
              <div style={{ color:C.muted, fontSize:14, marginTop:6 }}>Acesse sua escala ou gerencie as viagens da equipe.</div>
            </div>

            <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
              {/* Funcionário */}
              <button onClick={()=>setScreen("employee")} style={{
                display:"flex", alignItems:"center", gap:16,
                padding:"20px 22px", borderRadius:14,
                border:`2px solid ${C.bluePale}`, background:C.white,
                cursor:"pointer", textAlign:"left", fontFamily:"inherit",
                boxShadow:"0 2px 8px rgba(0,0,0,0.04)",
              }}>
                <div style={{
                  width:50, height:50, borderRadius:12, flexShrink:0,
                  background:`linear-gradient(135deg,${C.blue},#60A5FA)`,
                  display:"flex", alignItems:"center", justifyContent:"center", fontSize:22,
                }}>👤</div>
                <div>
                  <div style={{ fontWeight:700, fontSize:16, color:C.dark }}>Ver minha escala</div>
                  <div style={{ fontSize:13, color:C.muted, marginTop:2 }}>Consulte suas viagens agendadas</div>
                </div>
                <span style={{ marginLeft:"auto", color:C.bluePale, fontSize:22 }}>›</span>
              </button>

              {/* Admin */}
              <div style={{
                padding:"20px 22px", borderRadius:14,
                border:`1px solid ${C.border}`, background:C.white,
                boxShadow:"0 2px 8px rgba(0,0,0,0.03)",
              }}>
                <div style={{ display:"flex", alignItems:"center", gap:14, marginBottom:14 }}>
                  <div style={{
                    width:50, height:50, borderRadius:12, flexShrink:0,
                    background:`linear-gradient(135deg,#0F2A5C,${C.blue})`,
                    display:"flex", alignItems:"center", justifyContent:"center", fontSize:22,
                  }}>🔐</div>
                  <div>
                    <div style={{ fontWeight:700, fontSize:16, color:C.dark }}>Painel Administrativo</div>
                    <div style={{ fontSize:13, color:C.muted, marginTop:2 }}>Gerenciar viagens e funcionários</div>
                  </div>
                </div>
                <div style={{ display:"flex", gap:8 }}>
                  <input
                    type="password"
                    placeholder="Senha do administrador"
                    value={pass}
                    onChange={e=>{setPass(e.target.value);setPassErr(false);}}
                    onKeyDown={e=>e.key==="Enter"&&tryAdmin()}
                    style={{ ...inp, flex:1, border:`1px solid ${passErr?"#EF4444":C.border}` }}
                  />
                  <button onClick={tryAdmin} style={btnPrimary}>Entrar</button>
                </div>
                {passErr && <div style={{ color:C.red, fontSize:12, marginTop:6 }}>Senha incorreta.</div>}
                <div style={{ fontSize:11, color:"#CBD5E1", marginTop:8 }}>Senha padrão: dallatur2024</div>
              </div>
            </div>
          </div>
        )}

        {screen === "employee" && <EmployeeView state={state} />}

        {screen === "admin" && (
          <div>
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:20 }}>
              <div style={{ fontWeight:800, fontSize:17, color:C.blue }}>⚙️ Painel Admin</div>
              <button onClick={()=>setScreen("home")} style={btnGhost}>Sair</button>
            </div>
            <AdminPanel state={state} setState={setState} />
          </div>
        )}
      </div>
    </div>
  );
}
